const fs = require("fs");
const fetch = require("node-fetch");
const pdf = require("pdf-parse");

/**
 * AI Service V10 (INDEPENDENT CHATBOTS)
 */
class AIService {
    constructor() {
        this.openRouterKey = (process.env.OPENROUTER_API_KEY || "").trim();
        this.geminiKey = (process.env.GEMINI_API_KEY || "").trim();
        
        // Waterfall with high-reliability models
        this.modelWaterfall = [
            "google/gemini-2.0-flash:free",
            "google/gemini-2.0-flash-lite:preview-02-05:free",
            "google/gemini-2.0-flash-exp:free",
            "meta-llama/llama-3.3-70b-instruct:free",
            "mistralai/mistral-7b-instruct:free",
            "openrouter/auto"
        ];
        
        console.log("[AIService] Initialized with OpenRouter and Gemini support.");
    }

    /**
     * PDF/DOCUMENT ANALYSIS LOGIC (DO NOT TOUCH)
     */
    async processDocument(filePath, mimeType) {
        console.log(`[AIService] Doc: ${filePath}`);
        try {
            let documentText = "";
            if (mimeType === "application/pdf") {
                const dataBuffer = fs.readFileSync(filePath);
                const data = await pdf(dataBuffer);
                documentText = data.text;
            } else {
                documentText = fs.readFileSync(filePath, "utf8");
            }

            if (!documentText || documentText.trim().length < 5) {
                throw new Error("No text in document.");
            }

            const cleanText = documentText.split('\n').filter(l => l.trim().length > 0).join(' | ');
            const prompt = `System: You are an agentic CNDES analyst. Extract data as JSON.
User: Content below is from a PDF agenda. Extract an array of objects [ { title, date, startTime, endTime, location, description, participants[] } ].
- date format: YYYY-MM-DD
- time format: HH:mm
- participants: array of strings

Content:
${cleanText.substring(0, 15000)}`;

            // 1. OpenRouter with exhaustive waterfall
            for (const model of this.modelWaterfall) {
                try {
                    console.log(`[AIService] OR Try: ${model}`);
                    const content = await this.callOpenRouter(prompt, model);
                    if (content) return this.parseJSON(content);
                } catch (err) {
                    console.warn(`[AIService] ${model} failed: ${err.message}`);
                    await new Promise(r => setTimeout(r, 1000));
                }
            }

            // 2. Direct Gemini Fallback
            if (this.geminiKey) {
                try {
                    console.log("[AIService] Trying Direct Gemini (gemini-1.5-flash)...");
                    const content = await this.callDirectGemini(prompt, "gemini-1.5-flash");
                    return this.parseJSON(content);
                } catch (err) {
                    console.error("[AIService] Direct Gemini failed:", err.message);
                }
            }

            throw new Error("Saturación total. Prueba de nuevo en 1 min.");

        } catch (error) {
            console.error("[AIService] Global Error:", error);
            throw error;
        }
    }

    /**
     * CHATBOT / LECTOR ASSISTANT LOGIC (INDEPENDENT)
     */
    async askLector(userQuestion) {
        const db = require('./db');
        console.log(`[Lector] Question: ${userQuestion}`);
        
        try {
            // 0. Quick Greeting check
            const lowers = userQuestion.toLowerCase().trim();
            if (lowers.match(/^(hola|saludos|buenos días|buenas tardes|buenas noches|hey|quien eres)/)) {
                return "¡Hola! Soy el **Asistente Lector de CNDES**. Estoy aquí para ayudarte a consultar las actividades del calendario. ¿En qué puedo ayudarte hoy?";
            }

            // 1. Generate SQL
            const now = new Date();
            const todayISO = now.toISOString().split('T')[0];
            
            const sqlPrompt = `
Eres un experto en PostgreSQL para el sistema CNDES. 
Genera una ÚNICA CONSULTA SELECT válida para responder a la pregunta del usuario.

TABLAS:
- 'events' (id, title, "start", "end", location, description, participants)
  * "start" es un string ISO (ej: '2026-03-17T08:00:00.000Z')
- 'locations' (name)

CONTEXTO TEMPORAL:
- Fecha Actual: ${todayISO}

REGLAS:
1. Usa ILIKE para búsquedas de texto: title ILIKE '%termino%'.
2. Para consultas por día (ej: "qué hay hoy"), usa: "start" LIKE '${todayISO}%'.
3. Devuelve SOLO el SQL puro, sin markdown, sin comentarios.
4. Si no puedes responder con SQL, devuelve 'NONE'.

PREGUNTA: "${userQuestion}"
SQL:`;

            let generatedSQL = "";
            for (const model of this.modelWaterfall) {
                try {
                    const content = await this.callOpenRouter(sqlPrompt, model);
                    if (content && !content.includes("NONE")) {
                        generatedSQL = content.replace(/```sql/g, "").replace(/```/g, "").trim();
                        // Final safety check to ensure it's a SELECT
                        if (generatedSQL.toUpperCase().startsWith("SELECT")) break;
                    }
                } catch (e) {
                    console.error(`[Lector] SQL Error with ${model}:`, e.message);
                }
            }

            if (!generatedSQL) {
                return "No he podido generar la consulta para esa pregunta. Por favor, intenta ser más específico.";
            }

            console.log(`[Lector] Executing: ${generatedSQL}`);

            // 2. Execute SQL
            let results = [];
            try {
                results = await db.queryAsLector(generatedSQL);
            } catch (dbErr) {
                console.error("[Lector] Database error execution:", dbErr.message);
                return "Ha habido un error técnico al acceder a los datos. Por favor, reformula tu pregunta.";
            }
            
            if (!results || results.length === 0) {
                return "No he encontrado ninguna actividad o dato que coincida con tu consulta.";
            }

            // 3. Interpret Results
            const interpretationPrompt = `
Eres el Asistente Lector de CNDES. Responde de forma clara, profesional y amable a la pregunta del usuario usando los datos proporcionados de la base de datos.

REGLAS:
1. Usa tablas de Markdown para mostrar múltiples actividades.
2. NO menciones SQL, tablas, bases de datos o aspectos técnicos internos.
3. Si la lista de datos está vacía, indica que no hay registros.
4. Sé conciso pero informativo.

PREGUNTA DEL USUARIO: "${userQuestion}"
DATOS ENCONTRADOS (JSON): ${JSON.stringify(results.slice(0, 15))}

RESPUESTA PROFESIONAL:`;

            for (const model of this.modelWaterfall) {
                try {
                    const answer = await this.callOpenRouter(interpretationPrompt, model);
                    if (answer) return answer;
                } catch (e) {
                    console.error(`[Lector] Interpretation Error with ${model}:`, e.message);
                }
            }

            return "Tengo los datos pero he tenido un problema al redactar la respuesta. En resumen: hay " + results.length + " actividades encontradas.";

        } catch (err) {
            console.error("[Lector] Global error in askLector:", err);
            return "Lo siento, el servicio de asistencia no está disponible ahora.";
        }
    }

    async callOpenRouter(prompt, model) {
        if (!this.openRouterKey) throw new Error("Missing OpenRouter Key");
        
        const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${this.openRouterKey}`,
                "Content-Type": "application/json",
                "HTTP-Referer": "https://cndes-calendar.local",
                "X-Title": "CNDES AI Assistant"
            },
            body: JSON.stringify({
                model: model,
                messages: [{ role: "user", content: prompt }],
                temperature: 0.1
            })
        });

        if (!res.ok) {
            const error = await res.json().catch(() => ({}));
            throw new Error(error.error?.message || `HTTP ${res.status}`);
        }

        const data = await res.json();
        return data.choices?.[0]?.message?.content || "";
    }

    async callDirectGemini(prompt, model) {
        if (!this.geminiKey) throw new Error("Missing Gemini Key");
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${this.geminiKey}`;
        const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
                generationConfig: { temperature: 0.1 }
            })
        });

        if (!res.ok) {
            const err = await res.text();
            throw new Error(`Gemini Error: ${res.status} - ${err.substring(0, 100)}`);
        }

        const data = await res.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    }

    parseJSON(text) {
        try {
            const clean = text.replace(/```json/gi, "").replace(/```/g, "").trim();
            const parsed = JSON.parse(clean);
            if (Array.isArray(parsed)) return parsed;
            if (parsed.events) return parsed.events;
            if (parsed.activities) return parsed.activities;
            return [parsed];
        } catch (e) {
            const match = text.match(/\[[\s\S]*\]/);
            if (match) return JSON.parse(match[0]);
            throw new Error("Invalid JSON");
        }
    }
}

module.exports = new AIService();
